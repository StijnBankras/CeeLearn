﻿using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;

namespace CeeLearnAndDo
{
    public class Vraagbaak
    {
        public int VraagbaakID
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Chatgesprek
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int WerknemerID
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public Account Account
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public Guest Guest
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }

    public class VraagbaakDAL : BaseClass
    {
        public Vraagbaakpagina Vraagbaakpagina
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string GetChatgesprek()
        {
            throw new System.NotImplementedException();
        }

        public string Kickuser()
        {
            throw new System.NotImplementedException();
        }
    }
}