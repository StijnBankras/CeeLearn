﻿using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;

namespace CeeLearnAndDo
{
    public class Artikelen
    {
        public int ArtikelID
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string ArtikelOnderwerp
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string ArtikelTekst
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public Account Account
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }

    public class ArtikelenDAL : BaseClass
    {
        public Homepagina Homepagina
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public String GetArtikelen()
        {
            throw new System.NotImplementedException();
        }
    }
}