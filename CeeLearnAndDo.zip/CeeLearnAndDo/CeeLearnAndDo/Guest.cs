﻿using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;

namespace CeeLearnAndDo
{
    public class Guest
    {
        public String Naam
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string EMail
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int GuestID
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public Mail_A_Friend Mail_A_Friend
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public Vraagbaak Vraagbaak
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }
}