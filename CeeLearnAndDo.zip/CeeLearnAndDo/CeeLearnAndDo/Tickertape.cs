﻿using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;

namespace CeeLearnAndDo
{
    public class Tickertape
    {
        public String Reclamebericht
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int TickertapeID
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }

    public class TickertapeDAL : BaseClass
    {
        public Homepagina Homepagina
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Getmessages()
        {
            throw new System.NotImplementedException();
        }
    }
}