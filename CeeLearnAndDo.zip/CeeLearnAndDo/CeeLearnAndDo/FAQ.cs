﻿using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;

namespace CeeLearnAndDo
{
    public class FAQ
    {
        public string Vraag
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Antwoord
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int FAQID
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }

    public class FAQDAL : BaseClass
    {
        public FAQPagina FAQPagina
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public String GetQuestions()
        {
            throw new System.NotImplementedException();
        }
    }
}