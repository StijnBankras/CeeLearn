﻿using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;

namespace CeeLearnAndDo
{
    public class Eerdere_Projecten
    {
        public int EerdereProjecteID
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string ProjectOnderwerp
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public int ProjectTekst
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }

    public class ProjectenDAL : BaseClass
    {
        public Projectpagina Projectpagina
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public String GetProjecten()
        {
            throw new System.NotImplementedException();
        }
    }
}