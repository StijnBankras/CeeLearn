﻿using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;

namespace CeeLearnAndDo
{
    public class Mail_A_Friend
    {
        public int MailAFriendID
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string EmailGast
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string EmailZelf
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string AutomatischBericht
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public Guest Guest
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }

    public class MailAFriendDAL : BaseClass
    {
        public Homepagina Homepagina
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public String SendMessage()
        {
            throw new System.NotImplementedException();
        }

        public String GetAutomatischbericht()
        {
            throw new System.NotImplementedException();
        }
    }
}