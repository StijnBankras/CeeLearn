﻿using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;

namespace CeeLearnAndDo
{
    public class Account
    {
        public int AccountID
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Inlognaam
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public string Wachtwoord
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public Vraagbaak Vraagbaak
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public Artikelen Artikelen
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }

    public class AccountDAL : BaseClass
    {
        public Login Login
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }

        public bool authenticator()
        {
            throw new System.NotImplementedException();
        }

        public string RecoverPassword()
        {
            throw new System.NotImplementedException();
        }
    }
}