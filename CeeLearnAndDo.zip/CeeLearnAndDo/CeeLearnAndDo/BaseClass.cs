﻿using System;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.ComponentModel;

namespace CeeLearnAndDo
{
    public class BaseClass
    {
        public string Connection
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }
}